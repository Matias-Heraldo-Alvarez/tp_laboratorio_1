


#define  TITULO printf("\t\t ___________TRABAJO PRACTICO _NRO:1_____________\n");
#define  TITULO2 printf("\t\t ________________CALCULADORA____________________\n");
#define  TOLBAR printf("\t\t|-----------------------------------------------|\n");
#define  TOLBAR2 printf("\n\t\t|-----------------------------------------------|\n");

void chargePanel(float,float,int,int);
