#define  FACTORIAL_ERROR system("cls");printf("\n\tERROR ingrese solo numeros (ENTEROS POSITIVOS)\n\n\t");system("pause");

void basicOperation(float,float);

int validaFacorialTable(float);

int validaFacorial(float);

float validoOperando(float);

int validoOpcion();

