                                             //ok
#include "funciones.h"
#include "validaciones.h"

/** \brief devuelve el factorial n! de el valor signado por la funcion principal.
 *
 * \param valor es el numero pasado por la funcion principal.
 * \param resultado toma  el el factorial de valor (numero asignado por el usuario).
 * \return ( factorial del valor), en caso de que el valor pasado sea 0(cero) retorna 1.
 */

int getFactorial(int numero)//ok
{
    long int resultado = 0;

    if(numero >0){resultado = numero*getFactorial(numero - 1);}
    else{ resultado = 1;}

    return resultado;
}

/** \brief devuelve la suma de los valores asignados por la funcion principal.
 *
 * \param num1 almacena el primer valor .
 * \param num2 almacena el segundo valor.
 * \param result guarda la suma de los valores de num1 ynum2.
 * \return restorna el valor contenido en result.
 *
 */
float sum(float num1,float num2)//ok
{
 float result;

 result= num1+num2;
 return result;
}

/** \brief devuelve la resta de los valores asignados por la funcion principal.
 *
 * \param num1 almacena el primer valor .
 * \param num2 almacena el segundo valor.
 * \param result guarda la resta de los valores de num1 ynum2.
 * \return restorna el valor contenido en result.
 *
 */
float subtraction(float num1,float num2)//ok
{
    float result;

    result = num1 - num2;
    return result;
}

/** \brief devuelve la multiplcacion de los valores asignados por la funcion principal.
 *
 * \param num1 almacena el primer valor .
 * \param num2 almacena el segundo valor.
 * \param result guarda la division de los valores de num1 ynum2.
 * \return restorna el valor contenido en result ,en caso de que algun valor pasado sea 0 result -1.
 *
 */
 float division(float num1,float num2)//ok
{
     float result;


     if(num1==0 || num2==0){result = -1;}
     else{result = (float) num1/num2;}
     return  result;
}

/** \brief devuelve la division de los valores asignados  por la funcion principal.
 *
 * \param num1 almacena el primer valor .
 * \param num2 almacena el segundo valor.
 * \param result guarda la multiplicacion de los valores de num1 ynum2.
 * \return restorna el valor contenido en result ,en caso de que algun valor pasado sea 0 result -1.
 *
 */
float multiply(float num1,float num2)//ok
{
    float result;

    result = num1*num2;
    return result;
}

