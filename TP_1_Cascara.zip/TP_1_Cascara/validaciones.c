#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"
#include "validaciones.h"

/** \brief Muestra por pantalla una tabla de resultados de las operaciones basicas mas factorial.
 *
 * \param FactorialResult toma los valors de number1 mientras es validado,procesado y impreso en pantalla.
 * \param result guarda el el valor pasados (secuencialmente)por sum(),substraction(),division() y multiply()
 *        luego se usa para imprimirlos por pantalla en ese mismo orden.
 * \param ResulDivision guarda y muestra el valor pasado por division()y luego se usa para iprimirlo en pantalla.
 * \param number1 guarda el valor pasado por la funcion prncipal y se utiliza para todos los calculos.
 * \param number2 guarda el valor pasado por la funcion prncipal y se utiliza para todos los calculos.
 * \return (void).
 *
 */
void basicOperation(float number1,float number2)
{
 long int FactorialResult;
 float resultl;
 float ResultDivision;

    system("cls");
    printf("\t\t|-------------------------------------------------|\n");//ok
    printf("\t\t TABLA DE RESULTADOS:\n");

    resultl = sum(number1,number2);
    printf("\t\t Resultado:%.1f+%.1f = %.1f\n\n",number1,number2,resultl);//ok

    resultl = subtraction(number1,number2);
    printf("\t\t Resultado:%.1f-%.1f = %.1f\n\n",number1,number2,resultl);//ok

    ResultDivision = division(number1,number2);//ok
    if(ResultDivision == -1){printf("\t\t ERROR:(NO ES POSIBLE LA DIVISION ENTRE CERO(0).)\n\n");}
    else{printf("\t\t Resultado:%.1f%%%.1f = %.1f\n\n",number1,number2,ResultDivision);}

    FactorialResult = validaFacorialTable(number1);
    if(FactorialResult == number1)
    {FactorialResult = getFactorial(number1);printf("\t\t Reslutado:%0.f!      = %ld\n\n",number1,FactorialResult);}
    else{printf("\t\t Reslutado:A! =NO DISPONIBLE\n\n");}

    resultl = multiply(number1,number2);//ok
    printf("\t\t Resultado:%.1fx%.1f = %.1f\n\n",number1,number2,resultl);

    printf("\t\t|-------------------------------------------------|\n\n\n\n\n\t");
    system("pause");
}

/** \brief valida el numero para ser utilizado para dicho calculo..
 *
 * \param  entero guarda el valor de number para validar la perdida de datos flotantes
 *         se define que si no hay perdida  numero quedara con el valor ya cargado sino
 *         se le asigna el valor 0.
 * \param  number contiene el valor pasado por el programa.
 * \return entero.
 *
 */
int validaFacorialTable(float number)
{
  int entero;

  entero = number;
  if(number != entero || number<= -1){entero=0;}
  return entero;
}

/** \brief valida el numero pasado por el programa para utilizarlo en dicho calculo.
 *
 * \param entero toma el valor de number para validar si genera perdida de datos y
 *        en caso de tenerla toma valor =0.
 * \param number guarda el valor �sado por el programa para una pasarlo a entero.
 * \return entero
 *
 */
int validaFacorial(float number)
{
  int entero;

  entero = number;
  if(number != entero || number<= -1){entero=0;FACTORIAL_ERROR}
  return entero;
}


/** \brief Valida en ingreso de numeros unicamente .
 *
 * \param number guarda el valor pasado por el programa.
 * \param valid toma el valor de number  mas 1 y en caso de ingresar correctamente un valor
 *        por scanf()a number vuelve a tomar el valor actualizado de number.
 * \return valid.
 * El metodo de validacion respode a la caracteristica de scanf() que
 * de no poder leer el numero nos retorna 0 y de poder hacerlo retorna 1.
 */
float validoOperando(float number)//ok
{
    float valid= number+1;

    system("cls");
    printf("\tOperando:");
    fflush(stdin);
    if(scanf("%f",&number)!= 1){printf("\n\tERRROR(caracter invlido.)");system("pause");}
    else{valid = number;}

    return valid;
}

/** \brief Valida lo opcion ingresada por el usuario.
 *
 * \param option guarda la opcion ingresada por el usuario y
 *        es utilizado para hacer comparaciones loguicas.
 * \return option
 *         La metodologuia de validacion cosiste en la comparacion
 *         del valor asignado a los limites establecidos en un intervalo de 9 a 1.
 *         Ademas se tiene en cuenta lacaracteristica de scanf() de tener diferente retornso
 *         dependiendo de s pudo leer un  valor a no osilando entre 0 y 1 .
 */
int validoOpcion()
{
    int option;

    fflush(stdin);
    if(scanf("%d",&option)!= 1 || (option <= 0 || option >=10 )){printf("\t\tOPCION INVALIDA.");system("pause");option=0;}
    return option;
}
